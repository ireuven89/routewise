-- Migration 000008: Fix project_assignments foreign key
-- Date: 2026-01-28
-- Issue: project_assignments.worker_id was incorrectly referencing organization_users
-- Fix: Should reference workers table instead

-- Drop incorrect foreign key constraint
ALTER TABLE project_assignments 
DROP CONSTRAINT IF EXISTS project_assignments_worker_id_fkey;

-- Add correct foreign key to workers table
ALTER TABLE project_assignments 
ADD CONSTRAINT project_assignments_worker_id_fkey 
FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE;

COMMENT ON CONSTRAINT project_assignments_worker_id_fkey ON project_assignments 
IS 'References workers table (not organization_users)';
