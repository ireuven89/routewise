# RouteWise Database Migrations

## Overview

This directory contains all database migration files for the RouteWise application. Migrations are numbered sequentially and executed in order.

**Database:** PostgreSQL 15.x  
**Auto-migration:** Backend runs migrations on startup via `InitDB()`  
**Tracking:** `schema_migrations` table tracks executed migrations

---

## Migration Files

### 000005: Replace job_photos with project_files
**Purpose:** Comprehensive file management supporting photos, PDFs, and documents with AWS S3 integration

**Changes:**
- Drops legacy `job_photos` table
- Creates `project_files` table with:
  - File type categorization (photo, document, report)
  - File categories (progress, contract, invoice, etc.)
  - S3 storage metadata (bucket, key, url)
  - Polymorphic uploader tracking (user OR worker)
  - File metadata (size, mime type, extension)

**Key Features:**
- CHECK constraint ensures only one uploader type is set
- Indexes on project_id, file_type, category, uploaders
- S3 key format: `organizations/{org_id}/projects/{project_id}/{type}/{timestamp}_{filename}`

**Status:** ✅ Deployed to production

---

### 000006: Add construction fields and project assignments
**Purpose:** Support construction industry with multi-worker projects and enhanced project tracking

**Changes to jobs table:**
- `project_type` - Construction project category (residential, commercial, renovation)
- `project_value` - Total project cost
- `estimated_duration` - Duration in days (construction) or hours (HVAC)
- `actual_start_date` - Actual project start
- `actual_end_date` - Actual completion date

**New table: project_assignments**
- Tracks which workers are assigned to which projects
- Supports multiple workers per project (construction crews)
- Role tracking (foreman, electrician, laborer)
- Assignment history (assigned_at, removed_at)
- UNIQUE constraint prevents duplicate active assignments

**Industry Support:**
- **HVAC:** Uses `jobs.technician_id` for single-tech assignments
- **Construction:** Uses `project_assignments` for crew assignments
- Both patterns coexist in same schema

**Status:** ✅ Deployed to production

---

### 000007: Rename technicians to workers
**Purpose:** Clearer terminology for construction industry, consolidate field worker management

**Changes:**
- Renames `technicians` table → `workers`
- Enforces `phone NOT NULL` (required for authentication)
- Adds `is_active` column for soft deletes
- Adds `created_by` to track who added the worker
- Adds/ensures `created_at` and `updated_at` timestamps
- Adds `role` column for worker specialty
- UNIQUE constraint on `(organization_id, phone)`
- Performance indexes on organization, phone, active status

**Rationale:**
- "Workers" is more inclusive (construction crews, technicians, field staff)
- Soft delete preserves audit trail
- Phone-based authentication for mobile app

**Status:** ✅ Deployed to production

---

### 000008: Fix project_assignments foreign key
**Purpose:** Correct foreign key reference error in migration 000006

**Issue:**
- Migration 000006 incorrectly created:
  ```sql
  worker_id INTEGER REFERENCES organization_users(id)
  ```
- Should reference `workers` table, not `organization_users`

**Fix:**
- Drops incorrect foreign key constraint
- Adds correct foreign key: `worker_id REFERENCES workers(id)`

**Impact:**
- Fixes referential integrity
- Prevents errors when assigning workers to projects
- Required for construction industry project assignments

**Status:** ⚠️ NEEDS DEPLOYMENT (Created Jan 28, 2026)

---

## Deployment Instructions

### Local Development

```bash
# Migrations run automatically on app startup
cd backend
go run cmd/server/main.go

# Check logs for migration status
# Should see: "Running: 000005..." "Running: 000006..." etc.
```

### Production (EC2)

```bash
# Commit migrations
git add migrations/
git commit -m "Add migrations 000005-000008"
git push origin main

# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155

# Pull latest code
cd ~/routewise/backend
git pull origin main

# Restart service (runs migrations automatically)
sudo systemctl restart routewise

# Check logs
tail -f /var/log/routewise/app.log
# Look for: "Running: 000005..." "Running: 000006..." "Running: 000007..." "Running: 000008..."

# Verify migrations ran
sudo -u postgres psql routewise
SELECT version FROM schema_migrations ORDER BY version;
# Should see: 000005, 000006, 000007, 000008
\q
```

### Manual Migration (If Auto-migration Fails)

```bash
# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155

# Run migrations manually
cd ~/routewise/backend/migrations

# Run each migration in order
sudo -u postgres psql routewise -f 000005_replace_job_photos_with_project_files.up.sql
sudo -u postgres psql routewise -f 000006_add_construction_fields.up.sql
sudo -u postgres psql routewise -f 000007_rename_technicians_to_workers.up.sql
sudo -u postgres psql routewise -f 000008_fix_project_assignments_fkey.up.sql

# Update schema_migrations table
sudo -u postgres psql routewise << EOF
INSERT INTO schema_migrations (version) VALUES ('000005');
INSERT INTO schema_migrations (version) VALUES ('000006');
INSERT INTO schema_migrations (version) VALUES ('000007');
INSERT INTO schema_migrations (version) VALUES ('000008');
EOF
```

---

## Rollback Instructions

**WARNING:** Rollback will DELETE data. Only use in emergencies.

```bash
# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155
cd ~/routewise/backend/migrations

# Rollback migrations in REVERSE order
sudo -u postgres psql routewise -f 000008_fix_project_assignments_fkey.down.sql
sudo -u postgres psql routewise -f 000007_rename_technicians_to_workers.down.sql
sudo -u postgres psql routewise -f 000006_add_construction_fields.down.sql
sudo -u postgres psql routewise -f 000005_replace_job_photos_with_project_files.down.sql

# Remove from schema_migrations
sudo -u postgres psql routewise << EOF
DELETE FROM schema_migrations WHERE version = '000008';
DELETE FROM schema_migrations WHERE version = '000007';
DELETE FROM schema_migrations WHERE version = '000006';
DELETE FROM schema_migrations WHERE version = '000005';
EOF

# Restart backend
sudo systemctl restart routewise
```

---

## Verification Commands

### Check Migration Status

```bash
# Connect to database
sudo -u postgres psql routewise

-- View executed migrations
SELECT version FROM schema_migrations ORDER BY version;

-- Check tables exist
\dt

-- Verify project_files table
\d project_files

-- Verify workers table (not technicians)
\d workers

-- Verify project_assignments table
\d project_assignments

-- Check foreign keys
SELECT conname, conrelid::regclass, confrelid::regclass 
FROM pg_constraint 
WHERE conname LIKE '%project_assignments%';

-- Exit
\q
```

### Verify File Upload Working

```bash
# Test file upload endpoint
curl -X POST https://api.routewisehq.com/api/v1/projects/1/files \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@test.jpg" \
  -F "category=progress"

# Should return 201 with file metadata
```

---

## Migration Best Practices

**DO:**
- ✅ Always create both .up.sql and .down.sql
- ✅ Test migrations locally first
- ✅ Backup production database before major migrations
- ✅ Use IF EXISTS / IF NOT EXISTS for idempotency
- ✅ Add comments explaining the migration purpose
- ✅ Create indexes for foreign keys
- ✅ Use CHECK constraints for data integrity

**DON'T:**
- ❌ Edit migrations that have already been deployed
- ❌ Skip migration numbers
- ❌ Delete migration files
- ❌ Run migrations manually without updating schema_migrations
- ❌ Rollback in production without backup

---

## Troubleshooting

### Migration Already Exists Error
```
Error: migration 000007 already exists in schema_migrations
```
**Solution:** Migration already ran. No action needed.

### Foreign Key Violation
```
Error: insert or update on table violates foreign key constraint
```
**Solution:** 
- Check if related data exists
- Verify foreign key references correct table
- Run migration 000008 to fix project_assignments foreign key

### Table Already Exists
```
Error: relation "workers" already exists
```
**Solution:** 
- Migration partially completed
- Use `IF EXISTS` / `IF NOT EXISTS` in migrations
- Check schema_migrations table for status

### Permission Denied
```
Error: must be owner of table
```
**Solution:**
```bash
# Run as postgres user
sudo -u postgres psql routewise -f migration.sql
```

---

## Database Schema After All Migrations

**Tables:**
- organizations
- organization_users (office staff, web access)
- workers (field staff, mobile access)
- customers
- jobs (HVAC service calls + construction projects)
- project_files (photos, PDFs, documents in S3)
- project_assignments (worker → project mapping)
- schema_migrations (migration tracking)

**Key Features:**
- Multi-tenant isolation (organization_id everywhere)
- Polymorphic file uploads (users OR workers)
- Soft deletes (workers.is_active)
- AWS S3 integration for files
- Support for both HVAC and construction industries

---

## Questions?

**Backend auto-migration:** Runs on app startup via `InitDB()`  
**Manual migration:** Use psql commands above  
**Rollback:** Use .down.sql files in reverse order  

**Status:** 000005-000007 deployed ✅ | 000008 pending deployment ⚠️

---

**Last Updated:** January 28, 2026  
**Database Version:** PostgreSQL 15.x  
**Production Status:** Week 1 Complete, Week 2 Starting
