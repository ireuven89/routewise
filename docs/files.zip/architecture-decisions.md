# RouteWise Architecture Decision Records (ADRs)
**Project:** RouteWise SaaS  
**Period:** Week 1 Development  
**Date:** January 28, 2026

---

## Overview

This document records all significant architectural decisions made during RouteWise development, including context, alternatives considered, and rationale.

---

## ADR-001: Integer IDs vs UUIDs

**Date:** January 28, 2026  
**Status:** ✅ Accepted  
**Decision:** Use integer (SERIAL) primary keys, not UUIDs

### Context
Considering whether to use UUIDs for primary keys instead of auto-incrementing integers.

### Alternatives Considered

**Option 1: Integer IDs (SERIAL)**
```sql
id SERIAL PRIMARY KEY  -- 4-8 bytes, sequential
```

**Option 2: UUIDs**
```sql
id UUID PRIMARY KEY DEFAULT gen_random_uuid()  -- 16 bytes, random
```

### Decision
**Chosen: Integer IDs**

### Rationale

**Pros of Integers:**
- ✅ Smaller size (4-8 bytes vs 16 bytes)
- ✅ Faster indexing and joins
- ✅ Human-readable and debuggable
- ✅ Simple and familiar to developers
- ✅ Works perfectly for MVP

**Cons of Integers:**
- ⚠️ Sequential (can expose business metrics)
- ⚠️ Predictable (users could guess IDs)

**Why Acceptable:**
- All queries scoped by organization_id (multi-tenant isolation)
- Authorization checks prevent cross-org access
- Sequential IDs don't matter when properly scoped
- Example: `WHERE id = $1 AND organization_id = $2`

**Pros of UUIDs:**
- Globally unique
- Can generate client-side
- No centralized ID generation
- Can't infer creation order

**Cons of UUIDs:**
- Larger storage (4x size)
- Slower indexes
- Harder to debug (`WHERE id = '550e8400-e29b-41d4-a716-446655440000'`)
- Overkill for single-database SaaS

### Real-World Examples
Companies using integer IDs successfully:
- GitHub (repository IDs)
- Stripe (customer IDs, invoice IDs)
- Shopify (order IDs, product IDs)

### When to Reconsider
- Distributed databases (sharding)
- Client-side ID generation needed
- External API requires UUIDs
- Merger/acquisition scenarios

**Timeline:** Week 10+ (after revenue proven)

### Implementation
```sql
-- All tables use SERIAL
CREATE TABLE organizations (
    id SERIAL PRIMARY KEY,
    ...
);

CREATE TABLE jobs (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    ...
);
```

---

## ADR-002: Separate organization_users and workers Tables

**Date:** January 28, 2026  
**Status:** ✅ Accepted  
**Decision:** Use two separate tables instead of single users table with type field

### Context
Need to support two types of users:
- Office staff (web dashboard, email/password)
- Field workers (mobile app, phone/OTP)

### Alternatives Considered

**Option 1: Single Users Table**
```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER,
    email VARCHAR(255),
    phone VARCHAR(20),
    password VARCHAR(255),  -- Nullable?
    user_type VARCHAR(20)  -- 'office' or 'field'
);
```

**Option 2: Separate Tables (Chosen)**
```sql
CREATE TABLE organization_users (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,  -- Always required
    ...
);

CREATE TABLE workers (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,  -- Always required
    password VARCHAR(255),  -- Optional (OTP future)
    ...
);
```

### Decision
**Chosen: Separate Tables**

### Rationale

**Problems with Single Table:**
1. **Nullable password security risk:**
   - Office users REQUIRE password
   - Workers might use OTP (no password)
   - Making password nullable weakens security

2. **Different required fields:**
   - Office: email required, phone optional
   - Workers: phone required, email optional
   - Complex validation logic

3. **Different authentication flows:**
   - Office: Email/password via web
   - Workers: Phone/OTP via mobile
   - Mixed concerns in auth code

4. **Different access patterns:**
   - Office: Full dashboard, all features
   - Workers: Mobile-only, limited data
   - Different indexes needed

5. **Query complexity:**
   ```sql
   -- With single table
   SELECT * FROM users 
   WHERE organization_id = $1 
   AND user_type = 'office'
   AND is_active = true;
   
   -- With separate tables
   SELECT * FROM organization_users 
   WHERE organization_id = $1;
   ```

**Benefits of Separate Tables:**
- ✅ No nullable password issues
- ✅ Clear separation of concerns
- ✅ Different validation rules
- ✅ Optimized indexes per table
- ✅ Simpler authentication logic
- ✅ Better type safety

**Handling Polymorphic Relationships:**
Where both types need to be referenced (like file uploads):
```sql
CREATE TABLE project_files (
    uploaded_by_user INTEGER REFERENCES organization_users(id),
    uploaded_by_worker INTEGER REFERENCES workers(id),
    CHECK (
        (uploaded_by_user IS NOT NULL AND uploaded_by_worker IS NULL) OR
        (uploaded_by_user IS NULL AND uploaded_by_worker IS NOT NULL)
    )
);
```

### Implementation
- ✅ organization_users for office staff
- ✅ workers for field staff
- ✅ Polymorphic foreign keys where needed
- ✅ JWT includes user_type field

---

## ADR-003: Business Logic Location (Handlers vs Services)

**Date:** January 28, 2026  
**Status:** ⚠️ Deferred to Week 4  
**Decision:** Keep business logic in handlers for MVP, refactor to service layer post-MVP

### Context
Currently all business logic is in HTTP handlers. This is technical debt.

**Current Structure:**
```
Request → Handler (validation + business logic + response) → Repository → Database
```

**Better Structure:**
```
Request → Handler (thin) → Service (business logic) → Repository → Database
```

### Alternatives Considered

**Option 1: Refactor Now**
- Extract FileService, ProjectService, etc.
- Move all business logic to services
- Handlers become thin wrappers

**Time:** 1-2 days  
**Risk:** Delays mobile app

**Option 2: Ship MVP First (Chosen)**
- Keep current structure
- Refactor in Week 4 after customer
- Focus on features now

**Time:** 0 days  
**Technical Debt:** Accepted

### Decision
**Chosen: Ship MVP First, Refactor Week 4**

### Rationale

**Why Defer:**
- ✅ Code works correctly
- ✅ 13 days until customer demo
- ✅ Mobile app is priority
- ✅ Can refactor without time pressure
- ✅ Better to refactor with user feedback

**When to Refactor:**
- After first paying customer (Week 4)
- Before scaling team
- Before adding complex features

**Recommended Pattern (Future):**
```go
// Service layer
type FileService struct {
    fileRepo    *FileRepository
    projectRepo *ProjectRepository
    s3Service   *S3Service
}

func (s *FileService) UploadFile(ctx, params) (*File, error) {
    // 1. Validate project
    // 2. Upload to S3
    // 3. Save to DB
    // 4. Return file
}

// Handler becomes thin
func (h *FileHandler) Upload(c *gin.Context) {
    params := parseRequest(c)
    file, err := h.fileService.UploadFile(c.Request.Context(), params)
    if err != nil {
        c.JSON(500, gin.H{"error": err.Error()})
        return
    }
    c.JSON(201, gin.H{"file": file})
}
```

### Impact
- ✅ No impact on functionality
- ✅ Faster time to market
- ⚠️ Technical debt (managed)

---

## ADR-004: RDS Migration Timing

**Date:** January 28, 2026  
**Status:** ⚠️ Deferred to Week 4  
**Decision:** Defer PostgreSQL migration from EC2 to RDS until post-MVP

### Context
Currently running PostgreSQL on EC2 instance. AWS RDS offers managed database with better features.

### Alternatives Considered

**Option 1: Migrate to RDS Now**
- Better backups
- Automated updates
- Easier scaling
- High availability options

**Time:** 2-3 hours  
**Risk:** Could have issues, delays mobile app

**Option 2: Stay on EC2 for MVP (Chosen)**
- Current setup works
- One less thing to worry about
- Migrate when have breathing room

**Time:** 0 hours  
**Technical Debt:** Minimal

### Decision
**Chosen: Defer to Week 4**

### Rationale

**Current EC2 PostgreSQL:**
- ✅ Works perfectly
- ✅ Fast enough for MVP
- ✅ Backups configured
- ✅ Known configuration

**RDS Benefits (Don't Need Yet):**
- Automated backups (can do manually)
- Automated updates (not urgent)
- High availability (not needed for <100 users)
- Better monitoring (Sentry sufficient)

**When to Migrate:**
- After first paying customer
- Week 4-5 when have time
- Before scaling to 100+ users
- If database becomes bottleneck

**Migration Steps (Future):**
1. Create RDS instance
2. Dump EC2 database
3. Restore to RDS
4. Update backend connection string
5. Test thoroughly
6. Stop EC2 PostgreSQL

### Cost Impact
- EC2: $0 (already paying for instance)
- RDS: ~$15-30/month (db.t3.micro/small)
- Decision: Acceptable cost when have revenue

---

## ADR-005: Hebrew i18n Support Timing

**Date:** January 28, 2026  
**Status:** ⚠️ Deferred to Week 4  
**Decision:** English-only UI for MVP, add Hebrew post-MVP if needed

### Context
RouteWise targets Israeli market. Hebrew support would be beneficial but requires significant work.

### Scope of Hebrew Support

**UI Translation:**
- React web app: 7-10 hours
- React Native mobile: 7-10 hours
- Backend validation messages: 2 hours
- **Total: 16-22 hours**

**What's Involved:**
- Install i18n libraries
- Create translation files (en.json, he.json)
- Enable RTL (right-to-left) layout
- Fix layout issues in RTL mode
- Translate all UI strings
- Test thoroughly

### Alternatives Considered

**Option 1: Full Hebrew Support Now**
- Professional for Israeli market
- Better UX for Hebrew speakers
- Competitive advantage

**Time:** 16-22 hours (2-3 days)  
**Risk:** Delays mobile app by 2-3 days

**Option 2: English UI, Hebrew Data (Chosen)**
- UI in English
- Database supports Hebrew text input ✅
- Users can type Hebrew (already works)

**Time:** 0 hours  
**Compromise:** Acceptable for MVP

### Decision
**Chosen: English-only UI for MVP**

### Rationale

**Database Already Supports Hebrew:**
```sql
-- PostgreSQL UTF-8 encoding
-- Users can already type Hebrew
project_name: "שיפוץ מטבח ברחוב הרצל"  ← Works!
description: "עבודות חשמל ואינסטלציה"  ← Works!
```

**Why English UI Is Acceptable:**
- Many Israeli companies use English software
- Construction workers often bilingual
- AutoCAD, MS Project, etc. are in English
- Can add Hebrew UI later if customers request

**When to Add Hebrew:**
- Week 4+ based on customer feedback
- If customer specifically requests it
- When have time to do it properly
- Better RTL testing with real users

**What Customer Sees (MVP):**
```
[English UI Labels]
Project Name: שיפוץ מטבח  ← Hebrew text input works
Description: עבודות...     ← Hebrew text input works
```

### Implementation (Future)
If adding Hebrew in Week 4:
```javascript
// React Native
import i18n from 'i18next';
import { I18nManager } from 'react-native';

// Enable RTL
I18nManager.forceRTL(true);

// Use translations
const { t } = useTranslation();
<Text>{t('login')}</Text>  // התחברות or Login
```

---

## ADR-006: Project Assignment Strategy (Single vs Multi-Worker)

**Date:** January 28, 2026  
**Status:** ✅ Accepted  
**Decision:** Use simple technician_id field for MVP, migrate to project_assignments table post-MVP

### Context
Different industries have different assignment patterns:
- **HVAC:** 1 technician per service call
- **Construction:** Multiple workers (crew) per project

Database has BOTH approaches:
```sql
-- Simple (HVAC)
jobs.technician_id → Single worker

-- Complex (Construction)
project_assignments → Multiple workers per project
```

### Alternatives Considered

**Option 1: Use project_assignments (Multi-Worker)**
- Supports crews
- More realistic for construction
- Future-proof

**Requires:**
- Assignment API endpoints (2-3 hours)
- Mobile app assignment filtering
- More complex queries

**Option 2: Use technician_id (Single Worker) - Chosen**
- Already implemented
- Zero new code
- Simple queries

**Limitation:**
- Only 1 worker per project

### Decision
**Chosen: technician_id for MVP (Single Worker)**

### Rationale

**For MVP Demo:**
- Small construction companies (1-5 workers)
- Limit: 1 worker per project
- Owner verbally assigns: "Mike, work on Kitchen Reno today"
- Good enough for $50/month customer

**Mobile App Query:**
```sql
-- Simple: Worker sees their projects
SELECT * FROM jobs 
WHERE organization_id = $1 
AND technician_id = $2  -- Current worker's ID
```

**When to Migrate to project_assignments:**
- Week 4+ (after MVP)
- When customer needs multi-worker crews
- When scaling to larger companies (10+ workers)
- When customer explicitly requests it

**Migration Path (Future):**
```sql
-- 1. Migrate existing data
INSERT INTO project_assignments (project_id, worker_id, assigned_at)
SELECT id, technician_id, created_at 
FROM jobs 
WHERE technician_id IS NOT NULL;

-- 2. Update mobile app queries
SELECT DISTINCT j.* FROM jobs j
JOIN project_assignments pa ON j.id = pa.project_id
WHERE j.organization_id = $1 
AND pa.worker_id = $2
AND pa.removed_at IS NULL;

-- 3. Eventually deprecate technician_id
ALTER TABLE jobs DROP COLUMN technician_id;
```

### Implementation
**MVP (Current):**
- Use jobs.technician_id
- 1 worker per project
- Simple and fast

**Post-MVP (Week 4+):**
- Implement assignment endpoints
- Support multiple workers
- Keep both for transition period

---

## ADR-007: Permission Model Simplification

**Date:** January 28, 2026  
**Status:** ✅ Accepted  
**Decision:** Simple owner-only model for MVP, defer complex permissions

### Context
Database has role field supporting: 'owner', 'admin', 'manager'

Current implementation:
- ❌ No permission middleware
- ❌ No admin creation endpoint
- ❌ Role field exists but unused

### Alternatives Considered

**Option 1: Full Permission System**
```go
// Implement now
RequireOwner()         // Only owner
RequireOwnerOrAdmin()  // Owner or admin
RequireManager()       // Any role

// API endpoints
POST /users  // Create admins
POST /workers  // Create workers
```

**Time:** 1-2 days  
**Complexity:** High

**Option 2: Simple Owner-Only (Chosen)**
- Only owner role used
- No admin creation
- Owner does everything

**Time:** 0 days  
**Complexity:** Minimal

### Decision
**Chosen: Owner-Only for MVP**

### Rationale

**Current User Flow:**
```
1. Owner registers (creates org)
2. Owner adds workers
3. Owner creates projects
4. Workers upload photos
```

**No Admin Needed:**
- Small companies (1-5 workers)
- Owner manages everything
- Adding admin is premature
- Can add later if requested

**When to Add Permissions:**
- After first customer
- If customer requests: "Can I add my office manager?"
- Week 4+ when have time

**Future Implementation:**
```go
// Add permission middleware
func RequireOwner() gin.HandlerFunc {
    return func(c *gin.Context) {
        if c.GetString("role") != "owner" {
            c.JSON(403, gin.H{"error": "Only owners can do this"})
            c.Abort()
            return
        }
        c.Next()
    }
}

// Protect admin creation
protected.POST("/users", RequireOwner(), userHandler.Create)

// Allow owner/admin to create workers
protected.POST("/workers", RequireOwnerOrAdmin(), workerHandler.Create)
```

### Permission Matrix (Future)

| Action | Owner | Admin | Worker |
|--------|-------|-------|--------|
| Add admins | ✅ | ❌ | ❌ |
| Add workers | ✅ | ✅ | ❌ |
| Create projects | ✅ | ✅ | ❌ |
| Upload files | ✅ | ✅ | ✅ |
| Delete files | ✅ | ✅ | ❌ |

### Implementation
**MVP:** Owner-only, no permission checks  
**Week 4+:** Add middleware and admin role

---

## Summary of Decisions

| Decision | Status | Timeline |
|----------|--------|----------|
| Integer IDs (not UUIDs) | ✅ Accepted | Permanent |
| Separate user tables | ✅ Accepted | Permanent |
| Business logic in handlers | ⚠️ Deferred | Refactor Week 4 |
| EC2 PostgreSQL (not RDS) | ⚠️ Deferred | Migrate Week 4 |
| English-only UI | ⚠️ Deferred | Add Hebrew Week 4 if needed |
| Single worker assignments | ✅ Accepted | Migrate Week 4+ if needed |
| Owner-only permissions | ✅ Accepted | Expand Week 4 if needed |

**Trade-off Philosophy:** Speed to market over perfect architecture

**Justification:**
- 13 days until customer demo
- Technical debt is managed and documented
- All decisions are reversible
- Focus on revenue first, optimization later

---

## Decision-Making Framework

**When to Ship Now:**
- Feature works correctly ✅
- Scales to 10-100 users ✅
- Can refactor later without breaking changes ✅
- Time pressure (customer demo) ✅

**When to Do It Right:**
- Security-critical ⚠️
- Data loss risk ⚠️
- Breaking change (hard to fix later) ⚠️
- Customer-facing bugs ⚠️

**All Week 1 decisions passed the "Ship Now" criteria.**

---

**Document Status:** Complete  
**Last Updated:** January 28, 2026  
**Next Review:** Week 4 (Post-MVP)
