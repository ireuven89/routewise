-- Migration 000007 DOWN: Rollback workers to technicians

-- Rename workers back to technicians
ALTER TABLE workers RENAME TO technicians;

-- Remove soft delete column
ALTER TABLE technicians DROP COLUMN IF EXISTS is_active;

-- Remove created_by tracking
ALTER TABLE technicians DROP COLUMN IF EXISTS created_by;

-- Remove unique constraint
ALTER TABLE technicians DROP CONSTRAINT IF EXISTS workers_organization_phone_unique;

-- Restore old constraint (if it existed)
-- ALTER TABLE technicians ADD CONSTRAINT technicians_email_unique UNIQUE(email);
