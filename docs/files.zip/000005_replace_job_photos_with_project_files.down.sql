-- Migration 000005 DOWN: Rollback project_files to job_photos
-- WARNING: This will delete all file metadata. S3 files will remain orphaned.

-- Drop new table
DROP TABLE IF EXISTS project_files CASCADE;

-- Restore old table structure for rollback compatibility
CREATE TABLE job_photos (
    id SERIAL PRIMARY KEY,
    job_id INTEGER REFERENCES jobs(id) ON DELETE CASCADE,
    technician_id INTEGER REFERENCES workers(id),
    url TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE job_photos IS 'Legacy photo table (restored from rollback)';
