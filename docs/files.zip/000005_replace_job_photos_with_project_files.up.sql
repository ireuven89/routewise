-- Migration 000005: Replace job_photos with comprehensive project_files table
-- Date: 2026-01-28
-- Purpose: Support photos, PDFs, and documents with S3 storage

-- Drop old job_photos table (no data to preserve for MVP)
DROP TABLE IF EXISTS job_photos CASCADE;

-- Create comprehensive file management table
CREATE TABLE project_files (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    uploaded_by_user INTEGER REFERENCES organization_users(id),
    uploaded_by_worker INTEGER REFERENCES workers(id),
    
    -- File identification
    file_type VARCHAR(50) NOT NULL, -- 'photo', 'document', 'report'
    file_category VARCHAR(50), -- 'progress', 'contract', 'site_photo', 'invoice', etc.
    file_name VARCHAR(255) NOT NULL,
    original_file_name VARCHAR(255) NOT NULL,
    
    -- File metadata
    mime_type VARCHAR(100) NOT NULL,
    file_size INTEGER,
    file_extension VARCHAR(10),
    
    -- S3 storage
    s3_bucket VARCHAR(100) NOT NULL,
    s3_key TEXT NOT NULL,
    s3_url TEXT,
    
    -- Additional info
    description TEXT,
    taken_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Ensure only one uploader type is set
    CONSTRAINT check_one_uploader
        CHECK (
            (uploaded_by_user IS NOT NULL AND uploaded_by_worker IS NULL) OR
            (uploaded_by_user IS NULL AND uploaded_by_worker IS NOT NULL) OR
            (uploaded_by_user IS NULL AND uploaded_by_worker IS NULL)
        )
);

-- Indexes for performance
CREATE INDEX idx_project_files_project_id ON project_files(project_id);
CREATE INDEX idx_project_files_type ON project_files(file_type);
CREATE INDEX idx_project_files_category ON project_files(file_category);
CREATE INDEX idx_project_files_uploaded_by_user ON project_files(uploaded_by_user);
CREATE INDEX idx_project_files_uploaded_by_worker ON project_files(uploaded_by_worker);
CREATE INDEX idx_project_files_created_at ON project_files(created_at DESC);

-- Comments for documentation
COMMENT ON TABLE project_files IS 'Files (photos, PDFs, documents) uploaded to projects, stored in AWS S3';
COMMENT ON COLUMN project_files.uploaded_by_user IS 'Office user who uploaded (NULL if worker uploaded)';
COMMENT ON COLUMN project_files.uploaded_by_worker IS 'Field worker who uploaded (NULL if user uploaded)';
COMMENT ON COLUMN project_files.file_type IS 'General category: photo, document, or report';
COMMENT ON COLUMN project_files.file_category IS 'Specific category: progress, contract, invoice, etc.';
COMMENT ON COLUMN project_files.s3_key IS 'S3 object key: organizations/{org_id}/projects/{project_id}/{type}/{timestamp}_{filename}';
COMMENT ON COLUMN project_files.s3_url IS 'Presigned S3 URL (temporary, generated on demand)';
