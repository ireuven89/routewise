-- Migration 000007: Rename technicians to workers
-- Date: 2026-01-28
-- Purpose: Clearer terminology for construction industry, consolidate user types

-- Rename technicians table to workers
ALTER TABLE IF EXISTS technicians RENAME TO workers;

-- Ensure phone is required for workers (used for authentication)
ALTER TABLE workers ALTER COLUMN phone SET NOT NULL;

-- Add is_active column for soft deletes
ALTER TABLE workers ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- Add created_by to track who added the worker
ALTER TABLE workers ADD COLUMN IF NOT EXISTS created_by INTEGER REFERENCES organization_users(id);

-- Add timestamps if missing
ALTER TABLE workers ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE workers ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Add unique constraint on phone per organization
ALTER TABLE workers DROP CONSTRAINT IF EXISTS workers_organization_phone_unique;
ALTER TABLE workers ADD CONSTRAINT workers_organization_phone_unique 
    UNIQUE(organization_id, phone);

-- Ensure role column exists
ALTER TABLE workers ADD COLUMN IF NOT EXISTS role VARCHAR(50);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_workers_organization ON workers(organization_id);
CREATE INDEX IF NOT EXISTS idx_workers_phone ON workers(phone);
CREATE INDEX IF NOT EXISTS idx_workers_active ON workers(organization_id, is_active);
CREATE INDEX IF NOT EXISTS idx_workers_created_by ON workers(created_by);

-- Add comments for documentation
COMMENT ON TABLE workers IS 'Field workers with mobile app access (technicians, crew) - phone/OTP authentication';
COMMENT ON COLUMN workers.phone IS 'Phone number - always required, used for OTP authentication';
COMMENT ON COLUMN workers.is_active IS 'Active status - false for soft-deleted workers (preserves audit trail)';
COMMENT ON COLUMN workers.created_by IS 'Office user ID who added this worker';
COMMENT ON COLUMN workers.role IS 'Worker specialty: foreman, electrician, laborer, technician, etc.';
