# URGENT: Deploy Migration 000008

**Status:** ⚠️ CRITICAL - Must deploy before using project_assignments  
**Date:** January 28, 2026  
**Time Required:** 5 minutes

---

## What This Fixes

Migration 000006 created `project_assignments` table with **WRONG foreign key**:

```sql
-- WRONG! References office users instead of workers
worker_id INTEGER REFERENCES organization_users(id)

-- CORRECT! Should reference workers table
worker_id INTEGER REFERENCES workers(id)
```

---

## Impact if Not Deployed

**Will FAIL when:**
- Assigning worker to project
- Using project_assignments table
- Multi-worker project features

**Error:**
```
insert or update violates foreign key constraint
Key (worker_id)=(X) is not present in table "organization_users"
```

---

## Quick Deployment (5 minutes)

### Step 1: Commit Migration (Local)

```bash
cd ~/routewise/backend

# Ensure migration files exist
ls migrations/000008*
# Should see:
# 000008_fix_project_assignments_fkey.up.sql
# 000008_fix_project_assignments_fkey.down.sql

# Commit
git add migrations/000008*
git commit -m "Fix: project_assignments.worker_id should reference workers table"
git push origin main
```

---

### Step 2: Deploy to EC2

```bash
# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155

# Pull latest code
cd ~/routewise/backend
git pull origin main

# Restart service (auto-runs migrations)
sudo systemctl restart routewise

# Wait 5 seconds for startup
sleep 5

# Check logs for migration
tail -50 /var/log/routewise/app.log | grep "000008"
# Should see: "Running: 000008..." "Migration 000008 complete"
```

---

### Step 3: Verify (30 seconds)

```bash
# Still on EC2
sudo -u postgres psql routewise << 'EOF'

-- 1. Check migration ran
SELECT version FROM schema_migrations WHERE version = '000008';
-- Should return: 000008

-- 2. Verify foreign key
SELECT 
    conname as constraint_name,
    conrelid::regclass as table_name,
    confrelid::regclass as references_table
FROM pg_constraint 
WHERE conname = 'project_assignments_worker_id_fkey';
-- Should show: project_assignments → workers

-- 3. Check table structure
\d project_assignments
-- worker_id should show: REFERENCES workers(id)

EOF
```

**Expected output:**
```
 version 
---------
 000008
(1 row)

 constraint_name                      | table_name          | references_table
--------------------------------------+---------------------+-----------------
 project_assignments_worker_id_fkey   | project_assignments | workers
(1 row)
```

---

### Step 4: Test (Optional - 30 seconds)

```bash
# Test health endpoint
curl https://api.routewisehq.com/health
# Should return: {"status":"ok","database":"connected"}

# Test file upload still works
curl -X POST https://api.routewisehq.com/api/v1/projects/1/files \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@test.jpg"
# Should return: 201 with file data
```

---

## If Auto-Migration Fails

**Manual deployment:**

```bash
# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155

# Run migration manually
sudo -u postgres psql routewise -f ~/routewise/backend/migrations/000008_fix_project_assignments_fkey.up.sql

# Update tracking table
sudo -u postgres psql routewise -c "INSERT INTO schema_migrations (version) VALUES ('000008');"

# Verify
sudo -u postgres psql routewise -c "SELECT version FROM schema_migrations WHERE version = '000008';"

# Restart backend
sudo systemctl restart routewise
```

---

## Rollback (Emergency Only)

**If migration causes issues:**

```bash
# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155

# Run down migration
sudo -u postgres psql routewise -f ~/routewise/backend/migrations/000008_fix_project_assignments_fkey.down.sql

# Remove from tracking
sudo -u postgres psql routewise -c "DELETE FROM schema_migrations WHERE version = '000008';"

# Restart
sudo systemctl restart routewise
```

**WARNING:** Rollback restores the INCORRECT foreign key. Only rollback if migration breaks something else.

---

## Checklist

**Before deployment:**
- [ ] Migration files created locally
- [ ] Migration files committed to git
- [ ] Production database backed up (optional for this safe migration)

**During deployment:**
- [ ] Code pulled on EC2
- [ ] Service restarted
- [ ] Migration ran (check logs)
- [ ] No errors in logs

**After deployment:**
- [ ] Migration 000008 in schema_migrations table
- [ ] Foreign key references workers table
- [ ] Health endpoint responds
- [ ] File upload still works

---

## Why This Is Safe

**Low risk migration:**
- ✅ No data modification
- ✅ Only changes foreign key constraint
- ✅ project_assignments table likely empty (MVP)
- ✅ No dependent features currently using it
- ✅ Quick rollback if needed

**When to deploy:**
- ✅ Now (before using project_assignments)
- ✅ Before Week 2 mobile app
- ✅ Low traffic time (optional)

---

## After Deployment

**Update status:**
```
Migration 000008: ✅ DEPLOYED
Date: [fill in]
Deployed by: [your name]
```

**Continue with:**
- Week 2: React Native mobile app
- No dependencies on this migration for mobile app
- Safe to proceed immediately

---

## Questions?

**Migration failed?**
- Check logs: `tail -100 /var/log/routewise/app.log`
- Look for error messages
- Try manual deployment steps above

**Foreign key still wrong?**
- Verify migration ran: `SELECT version FROM schema_migrations WHERE version = '000008';`
- Check constraint: `\d project_assignments`
- Try manual migration

**Service won't start?**
- Check logs: `journalctl -u routewise -n 50`
- Verify database connection
- Check migration syntax

---

**DEPLOY THIS NOW - 5 MINUTES** ⚡

Then mark complete and continue with Week 2! 🚀
