# RouteWise Development Session Summary
**Date:** January 28, 2026  
**Session:** Week 1 Complete, Planning Week 2

---

## Session Overview

This session covered the completion of Week 1 backend development, troubleshooting production deployment issues, architectural decisions, and planning for Week 2 mobile app development.

---

## Major Accomplishments

### ✅ Week 1 Backend - COMPLETE

**File Upload System (Days 3-5):**
- Created S3Service with upload, download, delete functionality
- Built FileHandler with 4 REST endpoints
- Implemented FileRepository for database operations
- Polymorphic uploader tracking (office users OR workers)
- Production deployment successful

**API Endpoints Deployed:**
- `POST /api/v1/projects/:id/files` - Upload file to project
- `GET /api/v1/projects/:id/files` - List all files (with optional type filter)
- `GET /api/v1/files/:id` - Get single file with presigned URL
- `DELETE /api/v1/files/:id` - Delete file

**Production Status:**
- Backend running on EC2: https://api.routewisehq.com
- NGINX reverse proxy configured
- SSL certificate active (Let's Encrypt)
- Files uploading successfully to S3 bucket `routewise-project-files`
- Database migrations 000005-000007 deployed

---

## Technical Issues Resolved

### 1. User ID Context Mismatch
**Problem:** FileHandler looking for `user_id` but auth middleware sets `organization_user_id`

**Solution:** Updated FileHandler to use correct context key:
```go
userID := c.GetUint("organization_user_id")  // Match middleware
```

### 2. Foreign Key Constraint Violation
**Problem:** `project_files` table trying to insert `uploaded_by_user = 0`

**Root Cause:** Auth middleware not setting user_id properly

**Solution:** Verified auth middleware extracts and sets user info from JWT token

### 3. CHECK Constraint Violation
**Problem:** Both `uploaded_by_user` and `uploaded_by_worker` were NULL

**Root Cause:** `user_type` not in JWT token claims

**Solution:** 
- Added `user_type` field to JWT Claims struct
- Updated `GenerateToken()` to accept user_type parameter
- Registration/login now pass `"user"` as user_type
- FileHandler checks user_type to determine which field to populate

### 4. AWS Credentials Not Loading
**Problem:** S3 upload failing with "InvalidAccessKeyId"

**Root Cause:** Environment variables not set correctly

**Solution:** Used `.env` file with godotenv:
```bash
AWS_REGION=eu-north-1
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
S3_BUCKET_NAME=routewise-project-files
```

### 5. API Connection Timeout
**Problem:** `curl http://13.49.67.155:8080` timing out

**Root Cause:** Domain points to Vercel (frontend), not EC2 (backend)

**Solution:** Use API subdomain `api.routewisehq.com` pointing to EC2
- Production API: https://api.routewisehq.com
- Frontend proxies or calls API directly

### 6. Invalid Credentials on Production
**Problem:** Login returning "Invalid credentials" with known email/password

**Solution:** Email didn't exist in database - verified correct credentials from database

### 7. Project Not Found Error
**Problem:** File upload returning "Project not found"

**Root Cause:** Using wrong project ID that doesn't exist or doesn't belong to organization

**Solution:** 
- Created test project first
- Used correct project ID from database
- Verified `jobs.organization_id` matches user's org

---

## Database Architecture Decisions

### Data Model Finalized

**Two User Types (Separate Tables):**
- `organization_users` - Office staff (email/password, web dashboard)
- `workers` - Field staff (phone/OTP, mobile app)

**Rationale:**
- Avoids nullable password constraints
- Clear authentication separation
- Different access patterns (web vs mobile)

**Polymorphic Relationships:**
- `project_files.uploaded_by_user` OR `uploaded_by_worker`
- CHECK constraint ensures only one is set
- Tracks who uploaded each file

### Migration 000008 Created (Not Yet Deployed)

**Issue Found:** `project_assignments.worker_id` incorrectly references `organization_users(id)`

**Fix:** Should reference `workers(id)` instead

**Migration Created:**
```sql
ALTER TABLE project_assignments 
DROP CONSTRAINT IF EXISTS project_assignments_worker_id_fkey;

ALTER TABLE project_assignments 
ADD CONSTRAINT project_assignments_worker_id_fkey 
FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE;
```

**Status:** ⚠️ Needs deployment to production

---

## Architectural Decisions Made

### 1. Integer IDs vs UUIDs
**Decision:** Keep integer IDs for MVP

**Rationale:**
- Simpler implementation
- Faster indexing
- Queries already scoped by organization_id (security)
- Can add UUIDs later if needed
- No real benefit for single-tenant-per-org model

**When to reconsider:** Post-MVP if distributed ID generation needed

---

### 2. RDS Migration Timing
**Decision:** Defer RDS migration until Week 4+

**Rationale:**
- Current EC2 PostgreSQL works fine
- Migration takes 2-3 hours
- 13 days until customer demo
- Focus on mobile app instead
- Low-risk task that can wait

**When to do it:** After first paying customer (Week 4-5)

---

### 3. Hebrew i18n Support
**Decision:** English-only UI for MVP

**Rationale:**
- Saves 16-22 hours of work
- Database already supports Hebrew text (UTF-8) ✅
- Users can type Hebrew in forms ✅
- Many Israeli companies use English software
- Can add Hebrew UI in Week 4 if customer requests

**Compromise:** UI in English, data supports Hebrew

**When to add:** Week 4+ based on customer feedback

---

### 4. User Roles & Permissions

**Current Structure:**
- **Owner:** Full control (creates organization during registration)
- **Admin:** Management (future feature - not implemented yet)
- **Workers:** Mobile app only

**For MVP:**
- Only Owner role actively used
- No admin creation endpoint (not needed)
- Owner adds workers directly

**Permission Model (Simple):**
- Owner: Everything
- Workers: View assigned projects, upload files

**When to expand:** After MVP if customer needs admin role

---

### 5. Project Assignment Strategy

**Current State:**
- `jobs.technician_id` - Single worker assignment (HVAC pattern)
- `project_assignments` table - Multiple workers (Construction pattern)
- Both exist but only technician_id used for MVP

**Decision:** Use `technician_id` for MVP (1 worker per project)

**Rationale:**
- Already implemented
- Zero new code needed
- Mobile app shows "my projects" via simple query
- Good enough for small construction companies
- Can migrate to project_assignments later

**Query:**
```sql
SELECT * FROM jobs 
WHERE organization_id = $1 
AND technician_id = $2  -- Current worker
```

**Future Enhancement:** Use project_assignments for multi-worker crews

---

### 6. Business Logic Location

**Current State:** Business logic in handlers

**Concern Raised:** Should be in services, not handlers

**Decision:** Refactor AFTER MVP (Week 4+)

**Rationale:**
- Code works
- 13 days until demo
- Refactoring takes 1-2 days
- Better to refactor with user feedback
- Focus on shipping features

**Recommended Pattern (Post-MVP):**
```go
// FileService handles business logic
type FileService struct {
    fileRepo, projectRepo, s3Service
}

// Handler becomes thin
func (h *FileHandler) Upload(c *gin.Context) {
    params := parseRequest(c)
    file, err := h.fileService.UploadFile(ctx, params)
    c.JSON(201, gin.H{"file": file})
}
```

---

## Technology Stack Confirmed

**Backend:**
- Language: Go
- Framework: Gin
- Database: PostgreSQL 15.x (EC2, planned RDS migration)
- File Storage: AWS S3
- Authentication: JWT tokens
- Error Tracking: Sentry
- Logging: Standard Go log package + file logs
- Deployment: EC2 with systemd service

**Frontend Web:**
- Framework: React
- Hosting: Vercel
- Domain: routewisehq.com

**Frontend Mobile:**
- Framework: React Native (starting Week 2)
- Target: iOS + Android
- Authentication: JWT stored in AsyncStorage

**Infrastructure:**
- Web Server: NGINX (reverse proxy)
- SSL: Let's Encrypt (certbot)
- CI/CD: GitHub Actions (assumed)
- Monitoring: Sentry + manual log checking

---

## User Workflow Finalized

### Construction Company Flow:

**1. Registration (Owner):**
- Owner registers at routewisehq.com
- System creates organization + owner user
- Owner logs into web dashboard

**2. Add Workers (Owner):**
- Owner navigates to "Workers" → "Add Worker"
- Enters: Name, Phone, Role (foreman, electrician, etc.)
- Worker is created in `workers` table

**3. Worker Mobile Setup:**
- Worker downloads RouteWise mobile app
- Worker enters phone number
- Worker sets password (or uses OTP - future)
- Worker logs in

**4. Create Projects (Owner):**
- Owner creates project: Kitchen Renovation, Customer, Address
- Owner assigns worker via `technician_id` (for MVP)

**5. Worker Uploads Photos:**
- Worker opens mobile app
- Sees assigned projects
- Selects project → "Take Photo"
- Takes photo → Selects category (Progress, Site Photo, etc.)
- Uploads to S3 via API
- Owner sees photo in web dashboard

**6. Payment:**
- Customer pays $50/month subscription

---

## Week 2 Plan: React Native Mobile App

### Timeline: 7 Days (5 working days)

**Day 1 (Jan 29): Setup & Navigation**
- Initialize React Native project
- Install dependencies (navigation, axios, async-storage)
- Create folder structure
- Setup API service with base URL
- **Goal:** App running on simulator ✅

**Day 2 (Jan 30): Authentication**
- Create login screen UI
- Implement login API call
- Store JWT token in AsyncStorage
- Setup authenticated routes
- **Goal:** Worker can login ✅

**Day 3 (Jan 31): Projects List**
- Fetch projects from API
- Display project cards
- Navigate to project detail
- Pull-to-refresh
- **Goal:** Worker sees their projects ✅

**Day 4 (Feb 1): Project Detail + Files**
- Project detail screen
- Files tab (photos grid, documents list)
- Full-screen photo viewer
- Category badges
- **Goal:** Worker sees project files ✅

**Day 5 (Feb 2): Camera Integration**
- Install react-native-image-picker
- Take photo button
- Camera permissions
- Photo preview
- Upload with progress indicator
- **Goal:** Worker uploads photo from camera ✅

**Week 2 Deliverable:** Mobile app that uploads photos to production

---

## Week 3 Plan: Demo Preparation

**Days 1-2:** 
- Document picker for PDFs
- Category selection on upload
- Polish UI/UX
- Error handling
- Offline handling

**Day 3:**
- Test on real devices
- Fix critical bugs
- Performance optimization

**Day 4: CUSTOMER DEMO**
- Login as worker
- View projects
- Take/upload photo
- Upload PDF
- Show in web dashboard
- Collect feedback

**Day 5:**
- Fix demo issues
- Implement 1-2 quick wins
- Prepare onboarding
- **GOAL: Customer pays $50/month** 💰

---

## Files Generated This Session

### 1. Data Model Documentation
**File:** `routewise-data-model.md`
**Contents:**
- Complete table definitions
- Relationships diagram
- Design patterns
- Migration history
- Future enhancements

### 2. Migration Files
**Directory:** `migrations/`
**Files:**
- `000005_replace_job_photos_with_project_files.up.sql`
- `000005_replace_job_photos_with_project_files.down.sql`
- `000006_add_construction_fields.up.sql`
- `000006_add_construction_fields.down.sql`
- `000007_rename_technicians_to_workers.up.sql`
- `000007_rename_technicians_to_workers.down.sql`
- `000008_fix_project_assignments_fkey.up.sql`
- `000008_fix_project_assignments_fkey.down.sql`
- `README.md` (deployment instructions)

---

## Action Items

### Immediate (Before Week 2 Starts):

1. **Deploy Migration 000008**
   ```bash
   git add migrations/000008*
   git commit -m "Fix project_assignments foreign key"
   git push origin main
   # SSH to EC2, restart service
   ```

2. **Create Google Play Developer Account**
   - Type: Personal (for now)
   - Fee: $25 one-time
   - Purpose: Internal testing track
   - Upgrade to business later

3. **Initialize React Native Project**
   ```bash
   npx react-native@latest init RouteWiseMobile
   npm install dependencies
   ```

### Deferred (Post-MVP):

1. **RDS Migration** (Week 4)
2. **Hebrew i18n** (Week 4, if customer requests)
3. **Service Layer Refactoring** (Week 4)
4. **Complex Permissions** (Week 5+)
5. **Project Assignments Table** (Week 5+)
6. **Admin Role** (When customer requests)

---

## Key Metrics

**Timeline:**
- Week 1: 5 days (COMPLETE ✅)
- Week 2: 7 days (STARTING)
- Week 3: 6 days (DEMO PREP)
- **Total to Demo: 13 days remaining**

**Technical Debt Accepted:**
- Business logic in handlers (refactor later)
- Using technician_id instead of project_assignments (migrate later)
- English-only UI (add Hebrew later)
- EC2 PostgreSQL instead of RDS (migrate later)
- No admin role yet (add if needed)

**Trade-off:** Speed to market over perfect architecture

---

## Questions Answered

**Q: Should we use UUIDs instead of integer IDs?**  
A: No, keep integers. Good enough for MVP, can add later.

**Q: Should we refactor business logic to services?**  
A: Yes, but after MVP. Ship first, refactor later.

**Q: Hebrew support required?**  
A: Not for UI. Database supports Hebrew text. Add UI translation post-MVP.

**Q: RDS migration timing?**  
A: After first customer. Current setup works fine.

**Q: Admin vs Owner permissions?**  
A: Keep simple for MVP. Only owner, no admin role yet.

**Q: Project assignments - how to handle?**  
A: Use simple technician_id column for MVP (1 worker per project).

**Q: Organization_users vs workers - why two tables?**  
A: Clean separation, different auth, avoid nullable password issues.

---

## Production Environment Status

**API:** https://api.routewisehq.com ✅  
**Frontend:** https://routewisehq.com ✅  
**Database:** PostgreSQL on EC2 ✅  
**File Storage:** S3 bucket `routewise-project-files` ✅  
**SSL:** Let's Encrypt (auto-renew) ✅  
**Monitoring:** Sentry configured ✅  
**Logs:** `/var/log/routewise/app.log` ✅  

**Health Check:** https://api.routewisehq.com/health ✅

---

## Code Snippets Reference

### JWT Token Structure
```go
type Claims struct {
    UserID         uint   `json:"user_id"`
    OrganizationID uint   `json:"organization_id"`
    Email          string `json:"email"`
    Role           string `json:"role"`
    UserType       string `json:"user_type"` // "user" or "worker"
    jwt.StandardClaims
}
```

### FileHandler Upload (Simplified)
```go
func (h *FileHandler) Upload(c *gin.Context) {
    projectID := c.Param("id")
    orgID := c.GetUint("organization_id")
    userID := c.GetUint("organization_user_id")
    userType := c.GetString("user_type")
    
    // Verify project
    _, err := h.projectRepo.FindByID(projectID, orgID)
    
    // Get file
    file, header, _ := c.Request.FormFile("file")
    
    // Upload to S3
    s3Key := services.GenerateS3Key(orgID, projectID, fileType, filename)
    h.s3Service.UploadFile(ctx, file, s3Key, mimeType)
    
    // Determine uploader
    var uploadedByUser, uploadedByWorker *uint
    if userType == "worker" {
        uploadedByWorker = &userID
    } else {
        uploadedByUser = &userID
    }
    
    // Save to DB
    projectFile := &models.ProjectFile{
        ProjectID:        projectID,
        UploadedByUser:   uploadedByUser,
        UploadedByWorker: uploadedByWorker,
        // ... other fields
    }
    h.fileRepo.Create(projectFile)
    
    c.JSON(201, gin.H{"file": projectFile})
}
```

### API Service (React Native)
```javascript
// src/services/api.js
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'https://api.routewisehq.com/api/v1';

const api = axios.create({
  baseURL: API_URL,
  headers: {'Content-Type': 'application/json'},
});

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const login = (email, password) => 
  api.post('/login', {email, password});

export const getProjects = () => 
  api.get('/projects');

export const uploadFile = (projectId, formData) =>
  api.post(`/projects/${projectId}/files`, formData, {
    headers: {'Content-Type': 'multipart/form-data'},
  });

export default api;
```

---

## Next Session Preparation

**Before next session:**
1. Deploy migration 000008
2. Create Google Play account
3. Initialize React Native project
4. Install dependencies

**First task next session:**
- Verify React Native app runs on simulator
- Setup navigation structure
- Create API service file
- **Goal: 30-45 minutes to working app shell**

---

## Session Statistics

**Duration:** ~8 hours (full day session)  
**Files Created:** 11 (migrations + docs)  
**Issues Resolved:** 7 major technical issues  
**Decisions Made:** 6 architectural decisions  
**Lines of Documentation:** ~2000+  

**Key Achievement:** ✅ Week 1 Backend Complete & Production Deployed

---

**Status:** Ready for Week 2 Mobile App Development  
**Next Milestone:** Working mobile app with camera upload (5 days)  
**Final Goal:** First paying customer in 13 days 🎯

---

**End of Session Summary**  
**Date:** January 28, 2026  
**Next Session:** Week 2, Day 1 - React Native Setup
