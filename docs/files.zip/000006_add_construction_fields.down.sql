-- Migration 000006 DOWN: Rollback construction-specific fields
-- WARNING: This will delete project assignment history

-- Drop project assignments table
DROP TABLE IF EXISTS project_assignments CASCADE;

-- Remove construction-specific columns from jobs
ALTER TABLE jobs DROP COLUMN IF EXISTS project_type;
ALTER TABLE jobs DROP COLUMN IF EXISTS project_value;
ALTER TABLE jobs DROP COLUMN IF EXISTS estimated_duration;
ALTER TABLE jobs DROP COLUMN IF EXISTS actual_start_date;
ALTER TABLE jobs DROP COLUMN IF EXISTS actual_end_date;
