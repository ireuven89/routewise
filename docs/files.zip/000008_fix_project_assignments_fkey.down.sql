-- Migration 000008 DOWN: Rollback project_assignments foreign key fix
-- WARNING: This restores the incorrect foreign key reference

-- Drop correct foreign key
ALTER TABLE project_assignments 
DROP CONSTRAINT IF EXISTS project_assignments_worker_id_fkey;

-- Restore incorrect foreign key (for rollback compatibility)
ALTER TABLE project_assignments 
ADD CONSTRAINT project_assignments_worker_id_fkey 
FOREIGN KEY (worker_id) REFERENCES organization_users(id) ON DELETE CASCADE;
