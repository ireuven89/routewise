# RouteWise Migration Issues & Fixes
**Date:** January 28, 2026  
**Status:** Week 1 Complete - All Issues Resolved

---

## Overview

This document tracks all database migration issues discovered during development, their root causes, and solutions implemented.

---

## Issue 1: Missing project_files Table (Migration 000005)

### Problem
Original schema had `job_photos` table with limited functionality:
- Only supported photos (not PDFs or documents)
- Stored URLs directly (not S3 metadata)
- No file categorization
- No uploader tracking

### Solution: Migration 000005
**Created:** `project_files` table

**Features:**
- Supports multiple file types (photo, document, report)
- File categories (progress, contract, site_photo, invoice)
- S3 storage metadata (bucket, key, presigned URL)
- File metadata (size, mime type, extension)
- Polymorphic uploader tracking (user OR worker)

**Key Design:**
```sql
-- Polymorphic uploader
uploaded_by_user INTEGER REFERENCES organization_users(id),
uploaded_by_worker INTEGER REFERENCES workers(id),

-- Ensure only one is set
CONSTRAINT check_one_uploader
    CHECK (
        (uploaded_by_user IS NOT NULL AND uploaded_by_worker IS NULL) OR
        (uploaded_by_user IS NULL AND uploaded_by_worker IS NOT NULL) OR
        (uploaded_by_user IS NULL AND uploaded_by_worker IS NULL)
    )
```

**Why Polymorphic:**
- Office users can upload via web dashboard
- Workers can upload via mobile app
- Need to track who uploaded for audit trail
- Prevents nullable password constraints

**Status:** ✅ Deployed to production

---

## Issue 2: CRITICAL - Foreign Key Constraint in Migration 000006

### Problem
Migration 000006 created `project_assignments` table with **INCORRECT foreign key**:

```sql
-- WRONG!
worker_id INTEGER NOT NULL REFERENCES organization_users(id)
```

Should reference `workers` table, not `organization_users` table!

### Why This Happened
- Copy-paste error in migration
- organization_users = office staff
- workers = field staff
- project_assignments should track field workers assigned to projects

### Impact
- Attempting to assign worker to project would fail
- Foreign key violation on insert
- Breaks construction industry crew assignment feature

### Solution: Migration 000008
**Created:** Fix migration to correct the foreign key

```sql
-- Drop incorrect constraint
ALTER TABLE project_assignments 
DROP CONSTRAINT IF EXISTS project_assignments_worker_id_fkey;

-- Add correct constraint
ALTER TABLE project_assignments 
ADD CONSTRAINT project_assignments_worker_id_fkey 
FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE;
```

**Status:** ⚠️ Created, needs deployment to production

**Deployment:**
```bash
# SSH to EC2
ssh -i key.pem ubuntu@13.49.67.155

# Pull latest code
cd ~/routewise/backend
git pull origin main

# Restart service (auto-runs migration)
sudo systemctl restart routewise

# Verify
sudo -u postgres psql routewise
\d project_assignments
# Should see: worker_id → workers(id)
```

---

## Issue 3: File Upload - User ID = 0

### Problem
File upload failing with database error:
```
insert or update on table "project_files" violates foreign key constraint
Detail: Key (uploaded_by_user)=(0) is not present in table "organization_users"
```

### Root Cause
FileHandler was using wrong context key:

```go
// WRONG
userID := c.GetUint("user_id")  // Returns 0 if not set

// Auth middleware actually sets
c.Set("organization_user_id", claims.UserID)
```

### Solution
Updated FileHandler to use correct context key:

```go
// CORRECT
userID := c.GetUint("organization_user_id")
```

**Why the mismatch:**
- Auth middleware uses `organization_user_id` for clarity
- FileHandler was looking for generic `user_id`
- Context keys didn't match → returned 0

**Lesson:** Standardize context key names across application

**Status:** ✅ Fixed in production

---

## Issue 4: CHECK Constraint Violation - Both Uploaders NULL

### Problem
File upload failing with:
```
new row for relation "project_files" violates check constraint "check_one_uploader"
```

Both `uploaded_by_user` AND `uploaded_by_worker` were NULL.

### Root Cause
JWT token missing `user_type` field:

```go
// OLD Claims (missing user_type)
type Claims struct {
    UserID         uint
    OrganizationID uint
    Email          string
    Role           string
    // NO user_type field!
}
```

FileHandler checks `user_type` to determine which field to set:
```go
userType := c.GetString("user_type")  // Returns "" if not in JWT

if userType == "worker" {
    uploadedByWorker = &userID
} else {
    uploadedByUser = &userID  // Never executed if userType == ""
}
```

### Solution: Update JWT Claims

**1. Add user_type to Claims:**
```go
type Claims struct {
    UserID         uint   `json:"user_id"`
    OrganizationID uint   `json:"organization_id"`
    Email          string `json:"email"`
    Role           string `json:"role"`
    UserType       string `json:"user_type"` // NEW: "user" or "worker"
    jwt.StandardClaims
}
```

**2. Update GenerateToken signature:**
```go
// OLD
func GenerateToken(userID, orgID uint, email, role string) (string, error)

// NEW
func GenerateToken(userID, orgID uint, email, role, userType string) (string, error)
```

**3. Update registration/login:**
```go
// Registration
token, err := utils.GenerateToken(user.ID, user.OrganizationID, user.Email, user.Role, "user")

// Login
token, err := utils.GenerateToken(user.ID, user.OrganizationID, user.Email, user.Role, "user")

// Worker login (future)
token, err := utils.GenerateToken(worker.ID, worker.OrganizationID, worker.Email, worker.Role, "worker")
```

**4. Auth middleware extracts and sets:**
```go
func AuthMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        // Parse JWT
        claims := parseToken(token)
        
        // Set in context
        c.Set("organization_id", claims.OrganizationID)
        c.Set("organization_user_id", claims.UserID)
        c.Set("user_type", claims.UserType)  // NEW
        c.Set("role", claims.Role)
        
        c.Next()
    }
}
```

**Status:** ✅ Fixed in production

---

## Issue 5: Technicians vs Workers Table Name

### Problem
Table was named `technicians` which is:
- Too specific (only HVAC industry)
- Doesn't fit construction industry (electricians, laborers, foremen)
- Inconsistent with product vision (multi-industry SaaS)

### Solution: Migration 000007
Renamed `technicians` → `workers`

**Additional improvements:**
```sql
-- Enforce phone NOT NULL (required for auth)
ALTER TABLE workers ALTER COLUMN phone SET NOT NULL;

-- Add soft delete
ALTER TABLE workers ADD COLUMN is_active BOOLEAN DEFAULT true;

-- Track who added the worker
ALTER TABLE workers ADD COLUMN created_by INTEGER REFERENCES organization_users(id);

-- Add timestamps
ALTER TABLE workers ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE workers ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Unique phone per organization
ALTER TABLE workers ADD CONSTRAINT workers_organization_phone_unique 
    UNIQUE(organization_id, phone);
```

**Benefits:**
- More inclusive terminology
- Soft delete preserves audit trail
- Track who added each worker
- Unique phone prevents duplicates

**Status:** ✅ Deployed to production

---

## Issue 6: Construction vs HVAC Assignment Pattern

### Problem
Two different assignment patterns needed:

**HVAC:**
- Short service calls (1-4 hours)
- Single technician per job
- Simple assignment

**Construction:**
- Long projects (weeks/months)
- Multiple workers (crew of 5-10)
- Complex crew management
- Worker roles (foreman, electrician, laborer)

### Solution: Hybrid Approach

**Created BOTH patterns in schema:**

**1. Single assignment (HVAC):**
```sql
-- jobs table
technician_id INTEGER REFERENCES workers(id)
```

**2. Multi-worker assignment (Construction):**
```sql
-- project_assignments table
CREATE TABLE project_assignments (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES jobs(id),
    worker_id INTEGER NOT NULL REFERENCES workers(id),
    role VARCHAR(50),  -- 'foreman', 'electrician', etc.
    assigned_at TIMESTAMP,
    removed_at TIMESTAMP
);
```

**For MVP - Decision Made:**
Use simple `technician_id` approach (1 worker per project):

```sql
-- Worker query for "my projects"
SELECT * FROM jobs 
WHERE organization_id = $1 
AND technician_id = $2;
```

**Why:**
- Already implemented ✅
- Zero new code needed ✅
- Good enough for small construction companies (<5 workers)
- Can migrate to project_assignments later

**When to switch:**
- Post-MVP (Week 4+)
- When customer needs multi-worker crews
- When scaling to larger construction companies

**Status:** Decision made, using technician_id for MVP

---

## Issue 7: Organization_users vs Workers - Why Two Tables?

### Problem
Why not one `users` table with a `type` field?

### Considered Approach (Rejected):
```sql
-- Single table approach
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER,
    email VARCHAR(255),
    phone VARCHAR(20),
    password VARCHAR(255),  -- Nullable for workers?
    user_type VARCHAR(20)  -- 'office' or 'field'
);
```

### Problems with Single Table:
1. **Nullable password constraints:**
   - Office users: email + password (required)
   - Workers: phone + OTP (no password)
   - Makes password nullable → security risk

2. **Different authentication:**
   - Office: Email/password via web
   - Workers: Phone/OTP via mobile
   - Different flows, different validation

3. **Different access patterns:**
   - Office: Full dashboard access, all tables
   - Workers: Mobile-only, limited data
   - Mixed concerns in queries

4. **Different required fields:**
   - Office: email required, phone optional
   - Workers: phone required, email optional

### Solution: Separate Tables

**organization_users (Office Staff):**
```sql
CREATE TABLE organization_users (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,  -- Always required ✅
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),  -- Optional
    role VARCHAR(50) NOT NULL  -- 'owner', 'admin', 'manager'
);
```

**workers (Field Staff):**
```sql
CREATE TABLE workers (
    id SERIAL PRIMARY KEY,
    organization_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,  -- Always required ✅
    email VARCHAR(255),  -- Optional
    password VARCHAR(255),  -- For MVP (OTP future)
    role VARCHAR(50),  -- 'foreman', 'electrician', etc.
    is_active BOOLEAN DEFAULT true
);
```

**Benefits:**
- Clear separation of concerns
- No nullable password issues
- Clean authentication logic
- Better type safety
- Different indexes for different access patterns

**Polymorphic Relationships:**
Where needed (like file uploads), use:
```sql
uploaded_by_user INTEGER REFERENCES organization_users(id),
uploaded_by_worker INTEGER REFERENCES workers(id),
CHECK (only one is set)
```

**Status:** ✅ Architecture confirmed

---

## Migration Deployment Checklist

### Pre-Deployment
- [ ] Migrations tested locally
- [ ] Database backup created
- [ ] Migration 000008 committed to git

### Deployment Steps

**1. Commit migrations:**
```bash
cd ~/routewise/backend
git add migrations/
git commit -m "Add migration 000008: Fix project_assignments foreign key"
git push origin main
```

**2. Deploy to EC2:**
```bash
# SSH to EC2
ssh -i your-key.pem ubuntu@13.49.67.155

# Pull latest
cd ~/routewise/backend
git pull origin main

# Restart service (auto-runs migrations)
sudo systemctl restart routewise

# Check logs
tail -f /var/log/routewise/app.log
# Look for: "Running: 000008..."
```

**3. Verify migration:**
```bash
# Connect to database
sudo -u postgres psql routewise

# Check migration ran
SELECT version FROM schema_migrations ORDER BY version;
-- Should include: 000008

# Verify foreign key fixed
\d project_assignments
-- worker_id should reference workers(id)

# Test constraint
SELECT conname, confrelid::regclass 
FROM pg_constraint 
WHERE conname = 'project_assignments_worker_id_fkey';
-- Should show: workers table

\q
```

**4. Test functionality:**
```bash
# Test file upload still works
curl -X POST https://api.routewisehq.com/api/v1/projects/1/files \
  -H "Authorization: Bearer TOKEN" \
  -F "file=@test.jpg"
# Should return 201
```

### Post-Deployment
- [ ] Migration 000008 confirmed in schema_migrations
- [ ] Foreign key references workers table
- [ ] File upload still works
- [ ] No errors in logs

---

## Lessons Learned

### 1. Context Key Consistency
**Problem:** Different context keys in middleware vs handlers

**Solution:** Standardize naming:
- `organization_id` - Organization ID
- `organization_user_id` - User ID (from organization_users)
- `worker_id` - Worker ID (from workers)
- `user_type` - "user" or "worker"
- `role` - User role

### 2. JWT Claims Completeness
**Problem:** Missing fields in JWT caused downstream issues

**Solution:** Include all necessary fields:
- user_id
- organization_id
- email
- role
- **user_type** (critical for polymorphic relationships)

### 3. Foreign Key Validation
**Problem:** Copy-paste error in migration caused wrong foreign key

**Solution:**
- Review migrations carefully
- Test migrations locally first
- Use descriptive table names (workers vs users)
- Double-check relationship direction

### 4. Migration Naming
**Problem:** migration 000006 had generic name

**Recommendation:**
- Use descriptive names
- Include what changed
- Good: `000008_fix_project_assignments_fkey`
- Bad: `000008_update_tables`

### 5. Polymorphic Relationships
**Problem:** Complex to implement correctly

**Solution:**
- Use CHECK constraints to enforce rules
- Clear naming (uploaded_by_user vs uploaded_by_worker)
- Document why polymorphic is needed
- Provide examples in comments

---

## Future Migration Considerations

### Potential Migrations (Post-MVP)

**1. Add Admin Creation API**
- Endpoint: POST /api/v1/users
- Only owner can create admins
- Needs permission middleware

**2. Migrate to project_assignments**
- Phase out technician_id column
- Migrate existing assignments
- Update mobile app queries

**3. Add Worker OTP Authentication**
- phone_verified_at timestamp
- otp_code column (temporary)
- otp_expires_at timestamp

**4. Add File Versioning**
- file_version column
- previous_version_id self-reference
- Track file history

**5. Add Project Phases**
- project_phases table
- phase_id on project_files
- Track progress by phase

### Migration Best Practices

**DO:**
- Test locally first
- Backup before major changes
- Use IF EXISTS / IF NOT EXISTS
- Add helpful comments
- Create both .up and .down
- Run in transaction (when possible)
- Verify with queries after

**DON'T:**
- Edit deployed migrations
- Skip migration numbers
- Delete old migrations
- Deploy without testing
- Forget to update schema_migrations

---

## Quick Reference

### Check Migration Status
```bash
# See what's deployed
sudo -u postgres psql routewise -c "SELECT version FROM schema_migrations ORDER BY version;"
```

### Run Migration Manually
```bash
# If auto-migration fails
sudo -u postgres psql routewise -f migrations/000008_fix_project_assignments_fkey.up.sql

# Update tracking table
sudo -u postgres psql routewise -c "INSERT INTO schema_migrations (version) VALUES ('000008');"
```

### Rollback Migration
```bash
# Run down migration
sudo -u postgres psql routewise -f migrations/000008_fix_project_assignments_fkey.down.sql

# Remove from tracking
sudo -u postgres psql routewise -c "DELETE FROM schema_migrations WHERE version = '000008';"
```

---

## Summary

**Total Migrations:** 8 (000001-000008)

**Migration 000005:** ✅ Deployed - project_files table  
**Migration 000006:** ✅ Deployed - construction fields + project_assignments  
**Migration 000007:** ✅ Deployed - technicians → workers  
**Migration 000008:** ⚠️ **NEEDS DEPLOYMENT** - Fix project_assignments foreign key

**Critical Issue:** Migration 000008 must be deployed before using project_assignments table

**Status:** All other migrations deployed and working in production

**Next Steps:**
1. Deploy migration 000008
2. Verify in production
3. Continue with Week 2 mobile app

---

**Document Updated:** January 28, 2026  
**Production Status:** Week 1 Complete, Ready for Week 2
